let para = document.getElementById("para");

        let list1 = document.getElementById("list1");

        let noItem = document.createElement("h5");

        function add(){
            document.getElementById("box2").appendChild(noItem);
            document.getElementById("box2").removeChild(noItem);
            let list1 = document.getElementById("list1");
            let input = document.getElementById("input1");
            let item = document.createElement("li");
            if(input.value!=""){
                item.textContent = input.value;
                document.getElementById("list1").appendChild(item);
            }
            else{
                noItem.textContent = "Could not Add an Empty Item";
                noItem.style.color = "red";
                noItem.style.fontSize = "20px";
                document.getElementById("box2").appendChild(noItem);
            }
            
            //document.getElementById("box2").removeChild(noItem);
        }
        function remove(){
            let flag = 0;
            document.getElementById("box2").appendChild(noItem);
            document.getElementById("box2").removeChild(noItem);

            let list1 = document.getElementById("list1");
            let input = document.getElementById("input1");
            let items = document.getElementsByTagName("li");
            if(input.value!=""){
                if(items.length>0){
                for(i=0;i<items.length;i++){
                    if(input.value.trim() === items[i].textContent){
                        flag=1;
                        break;
                    }
                }
                if(flag===1){
                    list1.removeChild(items[i]);
                }
                else{
                    noItem.textContent = "Item Not present";
                    noItem.style.color = "red";
                    noItem.style.fontSize = "20px";
                    document.getElementById("box2").appendChild(noItem);
                }
            }
            else{                
                noItem.textContent = "No list items to Remove";
                noItem.style.color = "red";
                noItem.style.fontSize = "20px";
                document.getElementById("box2").appendChild(noItem);
            }
            }
            else{
                noItem.textContent = "Could not Remove an Empty Item";
                noItem.style.color = "red";
                noItem.style.fontSize = "20px";
                document.getElementById("box2").appendChild(noItem);
            }
            
        }

        let con = document.getElementById("div1");
        function text1(){
            con.textContent = "DOM manipulation is a fundamental aspect of web development. HTML (Hypertext Markup Language): The standard markup language for creating web pages and web applications. It defines the structure of content on a web page.";
        }
        function text2(){
            con.textContent = "TEXT Content 2";
        }
        function changeHtml(){ 
            let h3 = document.createElement("h3");
            h3.textContent = con.textContent;
            con.innerHTML = "";
            let h2 = document.createElement("h2");
            h2.textContent = "NEW HTML CONTENT";
            document.getElementById("div1").appendChild(h2);                        
            document.getElementById("div1").appendChild(h3);   
        }

        function hide(){
            let text = document.getElementById("text");
            let button = document.getElementById("button2");
            if(text.style.display !== "none"){
                text.style.display="none";  
                button.textContent = "SHOW";  
                button.style.color = "#ed425f";
                button.style.backgroundColor = "white";                         
            }
            else{
                text.style.display="block";  
                button.textContent = "HIDE"; 
                button.style.backgroundColor = "#ed425f";
                button.style.color = "white";                  
            }            
        }

        function hideImg(){
            let img1 = document.getElementById("img1");
            let buttonImg = document.getElementById("buttonImg");
            if(img1.style.visibility !== "hidden"){
                img1.style.visibility="hidden";  
                buttonImg.textContent = "SHOW"; 
                buttonImg.style.color = "#ed425f";
                buttonImg.style.backgroundColor = "white";              
            }
            else{
                img1.style.visibility="visible";  
                buttonImg.textContent = "HIDE";  
                buttonImg.style.backgroundColor = "#ed425f";
                buttonImg.style.color = "white";     
            }            
        }