//charmander, bulbasaur
async function fetchData(){
    try{
        
        let poke = document.getElementById("input1").value.toLowerCase();
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${poke}`);
        if(!response.ok){
            throw new Error("Could not fetch resource");                    
        }
        else{
            const data = await response.json();
            const pokeSprite = data.sprites.front_default;
            let img1 = document.getElementById("pokeImg");

            img1.src = pokeSprite;
            img1.style.display = "block";
            console.log(data);
        }
    }
    catch(error){
        alert(error);
    }
}


function loadDoc() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        let txt =  document.getElementById("demo");
        txt.innerHTML = this.responseText;
        txt.style.color = "white";
        txt.style.fontSize = "20px";
    }
    xhttp.open("GET", "ajax.txt");
    xhttp.send();
}