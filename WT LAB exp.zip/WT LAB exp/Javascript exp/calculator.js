let num1,num2;
function displayNum(num)
{
    let input = document.getElementById("input1");
    input.value  += num;
    input.style.color = "";
}

function add()
{
    let input = document.getElementById("input1");
    //num1 = input.value;
    input.value += "+";
    input.style.color = "";
}
function sub()
{
    let input = document.getElementById("input1");
    input.value += "-";
    input.style.color = "";

    let res = document.getElementById("h2Result");
    res.innerHTML += "-";
}
function multiply()
{
    let input = document.getElementById("input1");
    input.value += "*";
    input.style.color = "";

    let res = document.getElementById("h2Result");
    res.innerHTML += "*";
}
function divide()
{
    let input = document.getElementById("input1");
    input.value += "/";
    input.style.color = "";

    let res = document.getElementById("h2Result");
    res.innerHTML += "/";
}
function mod()
{
    let input = document.getElementById("input1");
    input.value += "%";
    input.style.color = "";

    let res = document.getElementById("h2Result");
    res.innerHTML += "%";
}
function clearInput()
{
    let input = document.getElementById("input1");
    input.value = "";

    let res = document.getElementById("h2Result");
    res.innerHTML += "";
}
function clearLast(){
    let input = document.getElementById("input1");
    input.value = input.value.slice(0,-1);
}
function square(){    
    let input = document.getElementById("input1");
    let res = document.getElementById("h2Result");
    let n = input.value;
    input.style.color = "";
    if(!isNaN(n)){
        input.value = Number(n)*Number(n);

        res.innerHTML =Number(n)*Number(n);
    }
    else{
        input.value = "Math Error";
        input.style.color = "red";
        res.innerHTML = "Math Error";
    }
}

function finalResult(){
    let input = document.getElementById("input1");
    try{
    let res = eval(input.value);
    input.value = res;
    input.style.color = "";
    } catch(error){
        input.value = "Math Error";
        input.style.color = "red";
        
    }  
}

function concat(){
    let input = document.getElementById("input1");
    let res="";
    input.style.color = "";
    if(input.value.includes("+")){
        let parts = input.value.split("+");
        for(let i in parts){
            res +=parts[i].trim();
        }
        input.value = res;
    }
    else{
        input.value = "Could not concatenate";
    }
}

/*function result()
{
    let input = document.getElementById("input1");

    let res = document.getElementById("h2Result");
    
    if(input.value.includes("+")){
        let parts = input.value.split("+");
        num1 = parts[0].trim();
        num2 = parts[1].trim();
        if(!isNaN(num1) && !isNaN(num2)){
            input.value = Number(num1)+Number(num2);

            res.innerHTML =Number(n)+Number(n);
        }
        else{
            input.value = "Math Error";

            res.innerHTML = "Math Error";
        }        
    }

    if(input.value.includes("-")){
        let parts = input.value.split("-");
        num1 = parts[0].trim();
        num2 = parts[1].trim();
        if(!isNaN(num1) && !isNaN(num2)){
            input.value = Number(num1)-Number(num2);

            res.innerHTML =Number(n)-Number(n);
        }
        else{
            input.value = "Math Error";

            res.innerHTML = "Math Error";
        }        
    }

    if(input.value.includes("*")){
        let parts = input.value.split("*");
        num1 = parts[0].trim();
        num2 = parts[1].trim();
        if(!isNaN(num1) && !isNaN(num2)){
            input.value = Number(num1)*Number(num2);

            res.innerHTML =Number(n)*Number(n);
        }
        else{
            input.value = "Math Error";

            res.innerHTML = "Math Error";
        }        
    }

    if(input.value.includes("/")){
        let parts = input.value.split("/");
        num1 = parts[0].trim();
        num2 = parts[1].trim();
        if(!isNaN(num1) && !isNaN(num2)){
            input.value = Number(num1)/Number(num2);

            res.innerHTML =Number(n)/Number(n);
        }
        else{
            input.value = "Math Error";

            res.innerHTML = "Math Error";
        }
    }

    if(input.value.includes("%")){
        let parts = input.value.split("%");
        num1 = parts[0].trim();
        num2 = parts[1].trim();
        if(!isNaN(num1) && !isNaN(num2)){
            input.value = Number(num1)%Number(num2);

            res.innerHTML =Number(n)%Number(n);
        }
        else{
            input.value = "Math Error";
            res.innerHTML = "Math Error";
        }
    }
    
    
}
*/

