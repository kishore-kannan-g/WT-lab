let submit = document.getElementById("submit");
        let clear = document.getElementById("clear");
        let detail = document.getElementById("details");

        submit.addEventListener('click', function(){
            let name = document.getElementById("name").value;
            let email = document.getElementById("email").value;
            let password = document.getElementById("password").value;

            localStorage.setItem("Lname", name);
            localStorage.setItem("Lemail", email);
            localStorage.setItem("Lpassword", password);

            alert("Data saved to local storage");
        });

        detail.addEventListener('click', function(){            
            let name = localStorage.getItem("Lname");
            let email = localStorage.getItem("Lemail");
            let password = localStorage.getItem("Lpassword");
            if(name !== null){
                document.getElementById("name").value = name;
            }
            else{
                document.getElementById("name").value = "---No data---";
            }
            if(email !== null){
                document.getElementById("email").value = email;
            }
            else{
                document.getElementById("email").value = "---No data---";
            }
            if(password !== null){
                document.getElementById("password").value = password;
            }
            else{
                document.getElementById("password").type = "text";
                document.getElementById("password").value = "---No data---";
            }                                    
        });

        clear.addEventListener('click', function(){
            localStorage.removeItem("Lname");
            localStorage.removeItem("Lemail");
            localStorage.removeItem("Lpassword");
            alert("Data cleared from local storage");
        });