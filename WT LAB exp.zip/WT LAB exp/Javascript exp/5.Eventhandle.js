let form1 = document.getElementById("form1");

       /* let btn = document.getElementById("submit");
        btn.addEventListener("click", function(){
            let name = document.getElementById("name").value;
            let email =  document.getElementById("email").value;         
            
            if(name == ""){
                alert("Pls enter name");
            }
            else if(!/^[a-zA-Z]+$/.test(name)){
                alert("Name can only contain letters.");
                //event.preventDefault();
            }
        });       */
       
        form1.addEventListener("submit", function(event){
            let name = document.getElementById("name").value;
            let email =  document.getElementById("email").value;         
            let password =  document.getElementById("password").value;  
            
            if(name == ""){
                alert("Pls enter name");
                event.preventDefault();
            }
            else if(!/^[a-zA-Z]+$/.test(name)){
                alert("Name can only contain letters.");
                event.preventDefault();
            }

            if(email ==""){
                alert("Pls enter email");
                event.preventDefault();
            }
            else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
                alert("ENter Valid email!!!");
                event.preventDefault();
            }

            if(password == ""){
                alert("Pls enter password");
                event.preventDefault();
            }
            else if(password.length < 8){
                alert("Password must be at least 8 characters");
                event.preventDefault();
            }

        });


        var movingElement = document.getElementById("box1");
        // Initial position
        var posX = 10;
        var posY = 10;
        // Add event listener for keyboard events
        document.addEventListener("keydown", function(event) {
            switch (event.key) {
                case "ArrowUp":
                    posY -= 10;
                    break;
                case "ArrowDown":
                    posY += 10;
                    break;
                case "ArrowLeft":
                    posX -= 10;
                    break;
                case "ArrowRight":
                    posX += 10;
                    break;
            }
            // Update element position
            movingElement.style.top = posY + "px";
            movingElement.style.left = posX + "px";
        });