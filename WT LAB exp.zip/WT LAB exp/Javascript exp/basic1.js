
function add(){
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let res = document.getElementById("res");    
    if(isNaN(n1) || isNaN(n2))
    {
        alert ("enter valid input!!");
    }
    else
    {
        res.value = (Number(n1)+Number(n2)); 
    }
    
}

function sub(){
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let res = document.getElementById("res");
    if(isNaN(n1) || isNaN(n2))
    {
        alert ("enter valid input!!");
    }
    else
    {
        res.value = (Number(n1)-Number(n2)); 
    }
    
}

function multiply(){
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let res = document.getElementById("res");
    if(isNaN(n1) || isNaN(n2))
    {
        alert ("enter valid input!!");
    }
    else
    {
        res.value = (Number(n1)*Number(n2)); 
    }
}

function divide(){
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let res = document.getElementById("res");
    if(isNaN(n1) || isNaN(n2))
    {
        alert ("enter valid input!!");
    }
    else
    {
        res.value = (Number(n1)/Number(n2)); 
    }
}

function concat(){
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let res = document.getElementById("res");
    res.value = (n1 + n2); 
}