let a =  [5, 2, 3, 1, 4];

function MinMax(){

    let val = document.getElementById("num1").value;
    let arr = val.split(",").map(Number);

    let min= Infinity;
    let max = 0;

    for(i=0;i<arr.length;i++)
    {
        if(max<arr[i])
        {
            max = arr[i];
        }
        if(min>arr[i])
        {
            min = arr[i];
        }
    }

    document.getElementById("result").innerHTML = "Max = "+max+"<br> Min = "+min ;

}