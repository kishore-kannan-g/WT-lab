function vote(){
let age = document.getElementById("age").value;
    if(Number(age)>18){
        alert("You are eligible for vote");
    }
    else{
        alert("Not eligible");
    }
}

function selectChoice(
    
){
    var ch = document.getElementById("choice");
    switch(ch.value){
        case "1":
            let age = prompt("ENter your age");
            if(Number(age)>=18){
                alert("You are eligible for vote");
            }
            else{
                alert("Not eligible");
            }
            break;
        case "2":
            let arr = prompt("Enter array elements");
            let ele = arr.split(",");
            let sum = 0,flag=0;
            for(var i in ele){
                if(!isNaN(ele[i])){
                    sum += Number(ele[i]);
                }
                else{
                    flag=1;
                    break;
                }
            }
            
            if(flag === 0){
                ele.sort((a, b) => a-b);
                alert("Sum of array = "+sum+"\nSorted Array = "+ele);
                
            }
            else{
                alert("Enter valid data");
            }
            break;
        case "3":
            let n = prompt("Enter a number");
            let f = 1;
            while(n>0){
                f = f * (n);
                n--;
            }
            alert("Factorial = "+f);
            break;
        default:
            alert("Enter valid data");
            break;
    }
}