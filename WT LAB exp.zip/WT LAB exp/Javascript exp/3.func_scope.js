function fact(){
    let input = document.getElementById("input1");
    let result = document.getElementById("result");
    result.innerHTML = "Factorial of "+input.value+" = "+factorial(input.value);
}
function factorial(n){  
    if(n == 0){
        return 1;
    }
    else{
        return (n*factorial(n-1));
    }            
}

function scope(){
    let input = document.getElementById("input2");
    let res2 = document.getElementById("result2");
    let l = input.value;
    var v = input.value;
    const c = input.value;
    res2.innerHTML = "Outside block:<br>let = "+l+"<br>var = "+v+"<br>const = "+c+"<br>";
    if(true){
        let l = "let in block";
        var v = "var in block";
        const c = "const in block";
        res2.innerHTML += "<br>Inside block:<br>let = "+l+"<br>var = "+v+"<br>const = "+c+"<br>";             
    }
    res2.innerHTML += "<br>After Inside block:<br>let = "+l+"<br>var = "+v+"<br>const = "+c+"<br>";

}

function scopeLex(){
    let input3 = document.getElementById("input3");
    let res3 = document.getElementById("result3");

    let out = input3.value;
    let out2="";
    
    function inner(){
        res3.innerHTML = "Hello "+out+"!!!<br> Welcome To Web Technology<br>";
        res3.innerHTML += "Length = "+out.length;
        for(let i=out.length-1;i>=0;i--){
            out2 += out[i];
        }
        res3.innerHTML += "<br>Reverse = "+out2;
        if(out === out2){
            res3.innerHTML += "<br>"+out+" is Palindrome ";
        }
        else{
            res3.innerHTML += "<br>"+out+" is not Palindrome ";
        }                
    }
    inner();
}