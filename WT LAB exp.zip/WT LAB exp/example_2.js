let cat = document.getElementById("cat_img");
cat.remove();
let dog = document.createElement("img");
dog.id = "dog_img";
dog.src = "dog_5.jpg";
document.body.append(dog);