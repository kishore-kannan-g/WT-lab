let n = Number(prompt("ENter your name"));
alert("Welcome "+(n+n)+" to JavaScript");  
document.write(n);